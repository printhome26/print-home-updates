
var SHOP = 'https://qur1es-yx.myshopify.com/api/2026-07/graphql.json';
var TOKEN = "dc005bc13cd16d7398f388645adeec74";
var UPDATE_URL = "https://github.com/printhome26/print-home-updates/releases/latest/download/latest.json";

function kvGet(k) { try { var r = CapacitorKV.get(k); return r && r.value ? r.value : ''; } catch (e) { return ''; } }
function kvSet(k, v) { try { CapacitorKV.set(k, String(v)); } catch (e) {} }

function sf(query) {
  return fetch(SHOP, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Shopify-Storefront-Access-Token': TOKEN },
    body: JSON.stringify({ query: query })
  }).then(function (r) { return r.json(); }).then(function (j) { return j.data || {}; });
}

var nid = 1;
function show(title, body) {
  try {
    CapacitorNotifications.schedule([{ id: Math.floor(Date.now() / 1000) % 2000000000 + (nid++), title: title, body: body, scheduleAt: new Date(Date.now() + 1000) }]);
  } catch (e) {}
}

// Erstes Mal nur merken, nicht melden (sonst kommen beim Installieren alte Sachen als "neu")
function changed(key, value) {
  var old = kvGet(key);
  kvSet(key, value);
  return old !== '' && old !== value;
}

function check() {
  if (kvGet('enabled') === 'false') return Promise.resolve();
  var jobs = [];
  if (TOKEN) {
    jobs.push(sf('query @inContext(country: AT, language: DE) { shop { metafield(namespace: "app", key: "promotions") { value } } articles(first: 1, sortKey: PUBLISHED_AT, reverse: true) { nodes { id title } } products(first: 1, sortKey: CREATED_AT, reverse: true) { nodes { id title } } }')
      .then(function (d) {
        try {
          var promos = JSON.parse((d.shop && d.shop.metafield && d.shop.metafield.value) || '[]').filter(function (p) { return p.id !== 'sale'; });
          var known = (kvGet('promoIds') || '').split('|');
          var fresh = promos.filter(function (p) { return known.indexOf(String(p.id)) < 0; });
          var first = kvGet('promoIds') === '';
          kvSet('promoIds', promos.map(function (p) { return p.id; }).join('|') || '-');
          if (!first && fresh.length) show('Neue Aktion bei Print Home', fresh[0].title || 'Jetzt in der App ansehen');
        } catch (e) {}
        var a = d.articles && d.articles.nodes && d.articles.nodes[0];
        if (a && changed('articleId', a.id)) show('Neu im Journal', a.title);
        var p = d.products && d.products.nodes && d.products.nodes[0];
        if (p && changed('productId', p.id)) show('Neu im Shop', p.title);
      }).catch(function () {}));
  }
  if (UPDATE_URL) {
    jobs.push(fetch(UPDATE_URL).then(function (r) { return r.json(); }).then(function (u) {
      var installed = parseInt(kvGet('appVersion') || '0', 10);
      var notified = parseInt(kvGet('notifiedVersion') || '0', 10);
      var v = parseInt(u.version || '0', 10);
      if (installed && v > installed && v > notified) {
        kvSet('notifiedVersion', v);
        show('Update für die Print Home App', 'Version ' + v + ' ist bereit – öffne die App zum Aktualisieren.');
      }
    }).catch(function () {}));
  }
  return Promise.all(jobs);
}

addEventListener('checkUpdates', function (resolve, reject, args) {
  check().then(function () { resolve(); }).catch(function () { resolve(); });
});

// Von der App aus: installierte Version & Ein/Aus-Schalter merken
addEventListener('setState', function (resolve, reject, args) {
  try {
    if (args && args.appVersion) kvSet('appVersion', args.appVersion);
    if (args && typeof args.enabled !== 'undefined') kvSet('enabled', args.enabled ? 'true' : 'false');
  } catch (e) {}
  resolve();
});
